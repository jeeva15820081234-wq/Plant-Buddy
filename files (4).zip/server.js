require('dotenv').config();
const express = require('express');
const path = require('path');
const app = express();
const KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
app.use(express.json({ limit: '12mb' }));
// ---- Locate index.html: prefer ./public/index.html, else ./index.html next to server.js ----
const fs = require('fs');
const PUBLIC_DIR = path.join(__dirname, 'public');
const INDEX_FILE = [path.join(PUBLIC_DIR, 'index.html'), path.join(__dirname, 'index.html')].find(f => fs.existsSync(f));
if (!INDEX_FILE) { console.error('\nERROR: index.html not found. Put it in the "public" folder (public\\index.html) or next to server.js.\n'); process.exit(1); }
console.log('Serving frontend from:', INDEX_FILE);
// Only serve a folder if index.html lives in it AND it is the dedicated public folder (never expose .env / server.js).
if (path.dirname(INDEX_FILE) === PUBLIC_DIR) app.use(express.static(PUBLIC_DIR));
app.get(['/', '/index.html'], (_, res) => res.sendFile(INDEX_FILE));

async function gemini(parts, { json = false, system } = {}) {
  if (!KEY) { const e = new Error('GEMINI_API_KEY is not set on the server. Add it to .env and restart.'); e.status = 503; throw e; }
  const body = { contents: [{ role: 'user', parts }], generationConfig: { temperature: json ? 0.2 : 0.7 } };
  if (json) body.generationConfig.responseMimeType = 'application/json';
  if (system) body.systemInstruction = { parts: [{ text: system }] };
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': KEY }, body: JSON.stringify(body)
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(data.error?.message || 'Gemini request failed'); e.status = r.status === 429 ? 429 : 502; throw e; }
  const text = data.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';
  if (!text) { const e = new Error('Gemini returned no content (the image may have been blocked).'); e.status = 502; throw e; }
  return text;
}

const IDENT_PROMPT = `You are a careful botanist. Identify the plant in the photo using only visible features (leaves, shape, flowers, stems, growth habit).
Reply with JSON only, matching exactly:
{"identified":boolean,"imageQuality":"good"|"poor","commonName":string,"scientificName":string,"category":string,"description":string,"confidence":number (0-1),"uncertainty":string,"alternatives":[string],"wateringDays":integer,"care":{"water":string,"light":string,"temperature":string,"humidity":string,"tips":string}}
Rules: If no plant is visible or the image is blurry/dark/too far, set identified=false, imageQuality="poor", and explain in "uncertainty" how to retake it. If you are not sure, lower the confidence, say why in "uncertainty", and list alternatives. Never invent a name; use "" for unknown strings. wateringDays = typical days between waterings (0 if unknown).`;

app.post('/api/identify', async (req, res) => {
  try {
    const m = /^data:(image\/(?:jpeg|png|webp));base64,(.+)$/.exec(req.body?.image || '');
    if (!m) return res.status(400).json({ error: 'Send a JPEG, PNG or WebP image as a base64 data URL.' });
    const text = await gemini([{ text: IDENT_PROMPT }, { inlineData: { mimeType: m[1], data: m[2] } }], { json: true });
    let out; try { out = JSON.parse(text.replace(/```json|```/g, '').trim()); } catch { return res.status(502).json({ error: 'The AI reply could not be read. Try again.' }); }
    res.json(out);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
});

app.post('/api/chat', async (req, res) => {
  try {
    const { message, history = [], plants = [] } = req.body || {};
    if (!message || typeof message !== 'string') return res.status(400).json({ error: 'Message is required.' });
    const system = `You are Mochi, a cheerful anime-style plant companion in the Plant Buddy app. Be warm, brief (under 120 words) and practical. Answer using the user's registered plants when relevant. If unsure, say so rather than guessing. Today is ${new Date().toDateString()}.\nUser's plants (JSON): ${JSON.stringify(plants).slice(0, 6000)}`;
    const convo = history.slice(-10).map(h => `${h.role === 'user' ? 'User' : 'Mochi'}: ${h.text}`).join('\n');
    const reply = await gemini([{ text: `${convo}\nUser: ${message}\nMochi:` }], { system });
    res.json({ reply: reply.trim() });
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
});

app.get('/api/health', (_, res) => res.json({ ok: true, aiConfigured: !!KEY, model: MODEL }));
// Unknown API routes -> JSON 404; any other unknown GET -> the app
app.use('/api', (_, res) => res.status(404).json({ error: 'Unknown API route.' }));
app.get('*', (_, res) => res.sendFile(INDEX_FILE));

const PORT = Number(process.env.PORT) || 3000;
const server = app.listen(PORT, () => console.log(`\nPlant Buddy running at http://localhost:${PORT}  (AI key ${KEY ? 'found' : 'MISSING - add GEMINI_API_KEY to .env'})\n`));
server.on('error', err => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\nPort ${PORT} is already in use (Plant Buddy may already be running in another window).`);
    console.error(`Fix: close the other window, or run:  netstat -ano | findstr :${PORT}   then   taskkill /PID <number> /F`);
    console.error(`Or use another port:  set PORT=3001 && npm start\n`);
  } else console.error('Server error:', err.message);
  process.exit(1);
});
