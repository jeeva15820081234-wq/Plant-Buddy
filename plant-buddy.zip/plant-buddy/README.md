# Plant Buddy
## Setup
1. Install Node 18+.
2. `npm install`
3. `cp .env.example .env` and set `GEMINI_API_KEY` (free key: https://aistudio.google.com/apikey).
4. `npm start` then open http://localhost:3000 (localhost is allowed to use the camera).
Frontend and backend run together; Express serves `public/`.
## Phone testing / HTTPS deployment
Browsers only allow the camera on HTTPS or localhost. Deploy to Render, Railway, Fly.io or a VPS
(set GEMINI_API_KEY as an environment variable there; they provide HTTPS), or behind Nginx/Caddy with a
Let's Encrypt certificate proxying to port 3000. For quick phone tests: `npx localtunnel --port 3000`.
## Data
Plants and photos: browser IndexedDB. XP, streaks, wishlist and chat: localStorage. (Per browser/device.)
